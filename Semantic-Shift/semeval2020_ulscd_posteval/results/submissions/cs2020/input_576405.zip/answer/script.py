import os
from sys import argv

fls = os.listdir(argv[1])
files = [argv[1] + '/' + f for f in fls]

for i,f in enumerate(files):
	with open(f) as file:
		lines = readlines(file)
	os.makekdirs('../answer_new', exist_ok=True)
	with open('/home/gand/Study/Science/Code/GoldbergBertWSI/' + fls[i] + '/targets.txt') as targets:
		targets = readlines
		with open(f + 'n', 'w+') as out:

